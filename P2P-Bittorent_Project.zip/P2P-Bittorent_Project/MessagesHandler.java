import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.BitSet;

public class MessagesHandler {

    private boolean _chokedByRemotePeer;
    private final int _remotePeerId;
    private final FileHandler _fileMgr;
    private final PeerHandler _peerMgr;
    private final LoggerMessages _eventLogger;

    MessagesHandler(int remotePeerId, FileHandler fileMgr, PeerHandler peerMgr, LoggerMessages eventLogger) {
        _chokedByRemotePeer = true;
        _fileMgr = fileMgr;
        _peerMgr = peerMgr;
        _remotePeerId = remotePeerId;
        _eventLogger = eventLogger;
    }

    public Messages handle(HandshakeMessage handshake) throws ClassNotFoundException {
        BitSet bitset = _fileMgr.getReceivedParts();
        if (!bitset.isEmpty()) {
            return (new Messages((byte) 5, bitset));
        }
        return null;
    }
    
    public Messages handle(Messages msg) throws ClassNotFoundException, IOException {
    	if(Byte.compare(msg.getType(), (byte) 0) == 0) {        //CHOKE
    		_chokedByRemotePeer = true;
            _eventLogger.logChoked(_remotePeerId);
            return null;
    	} 
    	else if(Byte.compare(msg.getType(), (byte) 1) == 0) {    //UNCHOKE
    		_chokedByRemotePeer = false;
            _eventLogger.logUnchoked(_remotePeerId);                
            return requestPiece();
    	}
    	else if(Byte.compare(msg.getType(), (byte) 2) == 0){      //Interested
    		_eventLogger.logInterested(_remotePeerId);
            _peerMgr.addInterestPeer(_remotePeerId);
            return null;
    	}
    	else if(Byte.compare(msg.getType(), (byte) 3) == 0){      //NOTInterested
    		_eventLogger.logNOTInterested(_remotePeerId);
            _peerMgr.removeInterestPeer(_remotePeerId);
            return null;
    	}
    	else if(Byte.compare(msg.getType(), (byte) 4) == 0){        //HAVE
    		final int pieceId = msg.pieceIndex();
            _eventLogger.logHave(_remotePeerId, pieceId);
            _peerMgr.haveArrived(_remotePeerId, pieceId);

            if (_fileMgr.getReceivedParts().get(pieceId)) {
                return new Messages((byte) 3);		//NOT-INTERESTED
            } else {
                return new Messages((byte) 2);		//INTERESTED
            }
    	}
    	else if(Byte.compare(msg.getType(), (byte) 5) == 0){        //BITFIELD
    		BitSet bitset = msg.getBitSet();
            _peerMgr.bitfieldArrived(_remotePeerId, bitset);

            bitset.andNot(_fileMgr.getReceivedParts());
            if (bitset.isEmpty()) {
                return new Messages((byte) 3);		//NOT-INTERESTED
            } else {
                // the peer has parts that this peer does not have
                return new Messages((byte) 2);		//INTERESTED
            }
    	}
    	else if(Byte.compare(msg.getType(), (byte) 6) == 0){        //REQUEST
    		if (_peerMgr.canUploadToPeer(_remotePeerId)) {
                byte[] piece = _fileMgr.getPiece(msg.pieceIndex());
                if (piece != null) {
                   return new Messages((byte) 7, msg.pieceIndex(), piece);       
                }
            }
            return null;
    	}
    	else if(Byte.compare(msg.getType(), (byte) 7) == 0){        //PIECE
    		_fileMgr.addPart(msg.pieceIndex(), msg.getPieceContent());
            _peerMgr.receivedPart(_remotePeerId, msg.getPieceContent().length);
            _eventLogger.logDownload(_remotePeerId, msg.pieceIndex(), _fileMgr.getNumberOfReceivedParts());
            return requestPiece();
    	}
    	return null;
    
    }

    private Messages requestPiece() throws ClassNotFoundException {
        if (!_chokedByRemotePeer) {
            int partId = _fileMgr.getPartToRequest(_peerMgr.getReceivedParts(_remotePeerId));
            if (partId >= 0) {
            	AssistLog.getLogger().debug("Requesting part " + partId + " to " + _remotePeerId);
            	byte[] pieceIdx = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(partId).array();
            	return new Messages((byte) 6, pieceIdx);
                   
            }
            else {
                AssistLog.getLogger().debug("No parts can be requested to " + _remotePeerId);
            }
        } 
        return null;
    }
}

