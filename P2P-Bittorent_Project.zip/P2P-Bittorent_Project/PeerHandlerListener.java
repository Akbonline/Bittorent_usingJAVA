import java.util.Collection;

public interface PeerHandlerListener {
    public void neighborsCompletedDownload();

    public void chockedPeers (Collection<Integer> chokedPeersIds);
    public void unchockedPeers (Collection<Integer> unchokedPeersIds);
}
