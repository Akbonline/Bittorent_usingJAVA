import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class PeerHandler implements Runnable {

    class OptimisticUnchoker extends Thread {
        private final int _numberOfOptimisticallyUnchokedNeighbors;
        private final int _optimisticUnchokingInterval;
        private final List<PeerInformation> _chokedNeighbors = new ArrayList<>();
        final Collection<PeerInformation> _optmisticallyUnchokedPeers =
                Collections.newSetFromMap(new ConcurrentHashMap<PeerInformation, Boolean>());

        OptimisticUnchoker(Configuration conf) {
            super("OptimisticUnchoker");
            _numberOfOptimisticallyUnchokedNeighbors = 1;
            _optimisticUnchokingInterval = Integer.parseInt(
                    conf.getNumberOfPreferredNeighbors().toString()) * 1000;
        }

        synchronized void setChokedNeighbors(Collection<PeerInformation> chokedNeighbors) {
            _chokedNeighbors.clear();
            _chokedNeighbors.addAll(chokedNeighbors);
        }

        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(_optimisticUnchokingInterval);
                } catch (InterruptedException ex) {
                }

                synchronized (this) {
                    // Randomly shuffle the remaining neighbors, and select some to optimistically unchoke
                    if (!_chokedNeighbors.isEmpty()) {
                        Collections.shuffle(_chokedNeighbors);
                        _optmisticallyUnchokedPeers.clear();
                        _optmisticallyUnchokedPeers.addAll(_chokedNeighbors.subList(0,
                                Math.min(_numberOfOptimisticallyUnchokedNeighbors, _chokedNeighbors.size())));
                    }
                }

                if (_chokedNeighbors.size() > 0) {
                    AssistLog.getLogger().debug("STATE: OPT UNCHOKED(" + _numberOfOptimisticallyUnchokedNeighbors + "):" + AssistLog.PeerIdToString (null, _optmisticallyUnchokedPeers));
                    _eventLogger.logOptUnchokNeighbor((int) AssistLog.PeerIdToString (null, _optmisticallyUnchokedPeers).get(1));
                }
                for (PeerHandlerListener listener : _listeners) {
                    listener.unchockedPeers(PeerInformation.SetIdAs(_optmisticallyUnchokedPeers));
                }
            }
        }
    }

    private final int _numberOfPreferredNeighbors;
    private final int _unchokingInterval;
    private final int _bitmapsize;
    private final LoggerMessages _eventLogger;
    private final List<PeerInformation> _peers = new ArrayList<>();
    private final Collection<PeerInformation> _preferredPeers = new HashSet<>();
    private final OptimisticUnchoker _optUnchoker;
    private final Collection<PeerHandlerListener> _listeners = new LinkedList<>();
    private final AtomicBoolean _randomlySelectPreferred = new AtomicBoolean(false);

    PeerHandler(int peerId, Collection<PeerInformation> peers, int bitmapsize, Configuration conf) {
        _peers.addAll(peers);
        _numberOfPreferredNeighbors = Integer.parseInt(
                conf.getNumberOfPreferredNeighbors());
        _unchokingInterval = Integer.parseInt(
                conf.getOptimisticUnchokingInterval()) * 1000;
        _optUnchoker = new OptimisticUnchoker(conf);
        _bitmapsize = bitmapsize;
        _eventLogger = new LoggerMessages (peerId);
    }

    synchronized void addInterestPeer(int remotePeerId) {
        PeerInformation peer = searchPeer(remotePeerId);
        if (peer != null) {
            peer.connRequested(1);		//Peer Interested
        }
    }

    long getUnchokingInterval() {
        return _unchokingInterval;
    }

    synchronized void removeInterestPeer(int remotePeerId) {
        PeerInformation peer = searchPeer(remotePeerId);
        if (peer != null) {
            peer.connRequested(0);		//Peer Not Interested
        }
    }

    synchronized List<PeerInformation> getInterestedPeers() {
        ArrayList<PeerInformation> interestedPeers = new ArrayList<>();
        for (PeerInformation peer : _peers){
            if((boolean) peer.capsule.get(5)){
                interestedPeers.add(peer);
            }
        }
        return interestedPeers;
    }

    synchronized boolean isInteresting(int peerId, BitSet bitset) {
        PeerInformation peer  = searchPeer(peerId);
        if (peer != null) {
            BitSet pBitset = (BitSet) peer.pktsreceived.clone();
            pBitset.andNot(bitset);
            return ! pBitset.isEmpty();
        }
        return false;
    }

    synchronized void receivedPart(int peerId, int size) {
        PeerInformation peer  = searchPeer(peerId);
        if (peer != null) {
            ((AtomicInteger) peer.capsule.get(4)).addAndGet(size); 
        }
    }

    synchronized boolean canUploadToPeer(int peerId) {
        PeerInformation peerInfo = new PeerInformation(peerId);
        return (_preferredPeers.contains(peerInfo) ||
                _optUnchoker._optmisticallyUnchokedPeers.contains(peerInfo));
    }

    synchronized void fileCompleted() {
        _randomlySelectPreferred.set (true);
    }

    synchronized void bitfieldArrived(int peerId, BitSet bitfield) {
        PeerInformation peer  = searchPeer(peerId);
        if (peer != null) {
            peer.pktsreceived = bitfield;
        }
        neighborsCompletedDownload();
    }

    synchronized void haveArrived(int peerId, int partId) {
        PeerInformation peer  = searchPeer(peerId);
        if (peer != null) {
            peer.pktsreceived.set(partId);
        }
        neighborsCompletedDownload();
    }

    synchronized BitSet getReceivedParts(int peerId) {
        PeerInformation peer  = searchPeer(peerId);
        if (peer != null) {
            return (BitSet) peer.pktsreceived.clone();
        }
        return new BitSet();  // empry bit set
    }

    synchronized private PeerInformation searchPeer(int peerId) {
        for (PeerInformation peer : _peers) {
            if ((int)(peer.capsule.get(0)) == peerId) {	 			
                return peer;
            }
        }
        AssistLog.getLogger().warning("Peer " + peerId + " not found");
        return null;
    }

    synchronized private void neighborsCompletedDownload() {
        for (PeerInformation peer : _peers) {
            if (peer.pktsreceived.cardinality() < _bitmapsize) {
                AssistLog.getLogger().debug("Peer " + peer.capsule.get(0) + " has not completed yet");
                return;
            }
        }
        for (PeerHandlerListener listener : _listeners) {
            listener.neighborsCompletedDownload();
        }
    }

    public synchronized void registerListener(PeerHandlerListener listener) {
        _listeners.add(listener);
    }

    @Override
    public void run() {

        _optUnchoker.start();

        while (true) {
            try {
                Thread.sleep(_unchokingInterval);
            } catch (InterruptedException ex) {
            }

           

            List<PeerInformation> interestedPeers = getInterestedPeers();
            if (_randomlySelectPreferred.get()) {
                // Randomly shuffle the neighbors
                AssistLog.getLogger().debug("selecting preferred peers randomly");
                Collections.shuffle(interestedPeers);
            }
            else {
                // Sort the peers in order of preference
                Collections.sort(interestedPeers, new Comparator() {
                    @Override
                    public int compare(Object o1, Object o2) {
                        PeerInformation ri1 = (PeerInformation) (o1);
                        PeerInformation ri2 = (PeerInformation) (o2);
                        // Sort in decreasing order
                        return (((AtomicInteger) ri2.capsule.get(4)).get() - ((AtomicInteger) ri1.capsule.get(4)).get());
                    }
                });
            }

            Collection<PeerInformation> optUnchokablePeers = null;

            Collection<Integer> chokedPeersIDs = new HashSet<>();
            Collection<Integer> preferredNeighborsIDs = new HashSet<>();
            Map<Integer, Long> downloadedBytes = new HashMap<>();

            synchronized (this) {
                // Reset downloaded bytes, but buffer them for debugging                  
                for (PeerInformation peer : _peers) {
                    downloadedBytes.put ((int) peer.capsule.get(0), ((AtomicInteger) peer.capsule.get(4)).longValue());		
                    ((AtomicInteger) peer.capsule.get(4)).set(0);			                }

                

                // Select the highest ranked neighbors as "preferred"
                _preferredPeers.clear();
                _preferredPeers.addAll(interestedPeers.subList(0, Math.min(_numberOfPreferredNeighbors, interestedPeers.size())));
                if (_preferredPeers.size() > 0) {
                    _eventLogger.logChangeOfPrefNeighbors(AssistLog.PeerIdToString (null, _preferredPeers).get(1).toString());  			
                }

                

                Collection<PeerInformation> chokedPeers = new LinkedList<>(_peers);
                chokedPeers.removeAll(_preferredPeers);
                chokedPeersIDs.addAll(PeerInformation.SetIdAs(chokedPeers));

                
                if (_numberOfPreferredNeighbors >= interestedPeers.size()) {
                    optUnchokablePeers = new ArrayList<>();
                }
                else {
                    optUnchokablePeers = interestedPeers.subList(_numberOfPreferredNeighbors, interestedPeers.size());
                }

                preferredNeighborsIDs.addAll (PeerInformation.SetIdAs(_preferredPeers));
            }

            // debug
            AssistLog.getLogger().debug("STATE: INTERESTED:" + AssistLog.PeerIdToString (null,interestedPeers));
            AssistLog.getLogger().debug("STATE: UNCHOKED (" + _numberOfPreferredNeighbors + "):" + AssistLog.PeerIdToString (preferredNeighborsIDs, null));
            AssistLog.getLogger().debug("STATE: CHOKED:" + AssistLog.PeerIdToString (chokedPeersIDs, null));
            
            for (Entry<Integer,Long> entry : downloadedBytes.entrySet()) {
                String PREFERRED = preferredNeighborsIDs.contains(entry.getKey()) ? " *" : "";
                AssistLog.getLogger().debug("BYTES DOWNLOADED FROM  PEER " + entry.getKey() + ": "
                        + entry.getValue() + " (INTERESTED PEERS: "
                        + interestedPeers.size()+ ": " + AssistLog.PeerIdToString (null, interestedPeers)
                        + ")\t" + PREFERRED);
            }

            

            for (PeerHandlerListener listener : _listeners) {
                listener.chockedPeers(chokedPeersIDs);
                listener.unchockedPeers(preferredNeighborsIDs);
            }
            
            

            if (optUnchokablePeers != null) {
                _optUnchoker.setChokedNeighbors(optUnchokablePeers);
            }
        }
        
    }
}
