import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

public class peerProcess {

    public static void main (String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        if (args.length != 1) {
            AssistLog.getLogger().severe("the number of arguments passed to the program is " + args.length + " while it should be 1.\nUsage: java peerProcess peerId");
        }
        final int peerId = Integer.parseInt(args[0]);
        AssistLog.configure(peerId);
        String address = "localhost";
        int port = 6008;
        boolean hasFile = false;

        // Read properties
        Reader commReader = null;
        Reader peerReader = null;
        Configuration commProp = null;
        PeerInformation peerInfo = new PeerInformation();
        Collection<PeerInformation> peersToConnectTo = new LinkedList<>();
        try {
            commReader = new FileReader (Configuration.get_File());
            peerReader = new FileReader (PeerInformation._confPeerInfo);
            commProp = new Configuration();
            commProp.setProperties (commReader);
            peerInfo.fetch (peerReader);
            List list = peerInfo.getPeerInfo();
            List<PeerInformation> list1 = (List<PeerInformation>)list;
            for (PeerInformation peer :  list1) {
                if (peerId == (int) peer.capsule.get(0)) {
                    address = (String) peer.capsule.get(1);
                    port = (int) peer.capsule.get(2);
                    hasFile = (boolean) peer.capsule.get(3);
                    break;
                }
                else { 
                    peersToConnectTo.add (peer);
                    AssistLog.getLogger().conf ("Read configuration for peer: " + peer);
                }
            }
        }
        catch (Exception ex) {
            AssistLog.getLogger().severe (ex.toString());
            return;
        }
        finally {
            try { commReader.close(); }
            catch (Exception e) {}
            try { peerReader.close(); }
            catch (Exception e) {}
        }

        Process peerProc = new Process (peerId, address, port, hasFile, peerInfo.getPeerInfo(), commProp);
        peerProc.init();
        Thread t = new Thread (peerProc);
        t.setName ("peerProcess-" + peerId);
        t.start();

        AssistLog.getLogger().debug ("Connecting to " + peersToConnectTo.size() + " peers.");
        peerProc.connectToPeers (peersToConnectTo);
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

