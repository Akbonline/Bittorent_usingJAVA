import java.io.IOException;
import java.util.Collection;
import java.util.TimerTask;

public class RequestTimer extends TimerTask {
    private final Messages _request;
    private final FileHandler _fileMgr;
    private final  Write _out;
    private final int _remotePeerId;
    private final Messages _message;

    RequestTimer (Messages request, FileHandler fileMgr, Write out, Messages message, int remotePeerId) {
        super();
        _request = request;
        _fileMgr = fileMgr;
        _out = out;
        _remotePeerId = remotePeerId;
        _message = message;
    }

    @Override
    public void run() {
        if (_fileMgr.hasPart(_request.pieceIndex())) {
            AssistLog.getLogger().debug("Not rerequesting piece " + _request.pieceIndex()
                    + " to peer " + _remotePeerId);
        }
        else {
        	AssistLog.getLogger().debug("Rerequesting piece " + _request.pieceIndex()
                    + " to peer " + _remotePeerId);
            try {
                _out.writeObjectData(_message);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
