

import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadHandler implements Runnable {

    private static final int PEER_ID_UNSET = -1;

    private final int _localPeerId;
    private final Socket _socket;
    private final Write _out;
    private final FileHandler _fileMgr;
    private final PeerHandler _peerMgr;
    private final boolean _isConnectingPeer;
    private final int _expectedRemotePeerId;
    private final AtomicInteger _remotePeerId;
    private final BlockingQueue<Messages> _queue = new LinkedBlockingQueue<>();

    public ThreadHandler(int localPeerId, Socket socket, FileHandler fileMgr, PeerHandler peerMgr)
            throws IOException {
        this(localPeerId, false, -1, socket, fileMgr, peerMgr);
    }

    public ThreadHandler(int localPeerId, boolean isConnectingPeer, int expectedRemotePeerId,
                             Socket socket, FileHandler fileMgr, PeerHandler peerMgr) throws IOException {
        _socket = socket;
        _localPeerId = localPeerId;
        _isConnectingPeer = isConnectingPeer;
        _expectedRemotePeerId = expectedRemotePeerId;
        _fileMgr = fileMgr;
        _peerMgr = peerMgr;
        _out = new Write(_socket.getOutputStream());
        _remotePeerId = new AtomicInteger(PEER_ID_UNSET);
    }

    public int getRemotePeerId() {
        return _remotePeerId.get();
    }

    @Override
    public void run() {
        new Thread() {

            private boolean _remotePeerIsChoked = true;

            @Override
            public void run() {
                Thread.currentThread().setName(getClass().getName() + "-" + _remotePeerId + "-sending thread");
                while (true) {
                    try {
                        final Messages message = _queue.take();
                        if (message == null) {
                            continue;
                        }
                        if (_remotePeerId.get() != PEER_ID_UNSET) {
                        	if(Byte.compare(message.getType(), (byte) 0) == 0){		//CHOKE
                        		if (!_remotePeerIsChoked) {
                                    _remotePeerIsChoked = true;
                                    sendInternal(message);
                                }
                        	} else if (Byte.compare(message.getType(), (byte) 1) == 0){		//UNCHOKE
                        		if (_remotePeerIsChoked) {
                                    _remotePeerIsChoked = false;
                                    sendInternal(message);
                                }
                        	}else {
                        		sendInternal(message);
                        	}
                        } else {
                            AssistLog.getLogger().debug("cannot send message of type "
                                    + message.getType() + " because the remote peer has not handshaked yet.");
                        }
                    } catch (IOException ex) {
                    	AssistLog.getLogger().warning(ex.toString());
                    } catch (InterruptedException ex) {
                    }
                }
            }
        }.start();

        try {
            final Read in = new Read(_socket.getInputStream());

            // Send handshake
            _out.writeObjectData(new HandshakeMessage(_localPeerId));

            // Receive and check handshake
            HandshakeMessage rcvdHandshake = (HandshakeMessage) in.readData();
            _remotePeerId.set(rcvdHandshake.getIntPeerID());
            Thread.currentThread().setName(getClass().getName() + "-" + _remotePeerId.get());
            final LoggerMessages eventLogger = new LoggerMessages(_localPeerId);
            final MessagesHandler msgHandler = new MessagesHandler(_remotePeerId.get(), _fileMgr, _peerMgr, eventLogger);		
            if (_isConnectingPeer && (_remotePeerId.get() != _expectedRemotePeerId)) {
                throw new Exception("Remote peer id " + _remotePeerId + " does not match with the expected id: " + _expectedRemotePeerId);
            }

            // Handshake successful
            if(_isConnectingPeer) {
            	eventLogger.logTCPConnection(_remotePeerId.get());
            }else if (!_isConnectingPeer) {
            	eventLogger.logTCPConnected(_remotePeerId.get());
            }

            sendInternal(msgHandler.handle(rcvdHandshake));
            while (true) {
                try {
                    sendInternal(msgHandler.handle((Messages) in.readMsgData()));   
                } catch (Exception ex) {
                	AssistLog.getLogger().warning(ex.toString());
                    break;
                }
            }
        } catch (Exception ex) {
        	AssistLog.getLogger().warning(ex.toString());
        } finally {
            try {
                _socket.close();
            } catch (Exception e) {
            }
        }
        AssistLog.getLogger().warning(Thread.currentThread().getName()
                + " terminating, messages will no longer be accepted.");
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ThreadHandler) {
            return ((ThreadHandler) obj)._remotePeerId == _remotePeerId;
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + _localPeerId;
        return hash;
    }

    public void send(final Messages message) {
        _queue.add(message);
    }

    private synchronized void sendInternal(Messages message) throws IOException {
        if (message != null) {
            _out.writeObjectData(message);
            if(Byte.compare(message.getType(), (byte) 6) == 0){       //REQUEST
            	new java.util.Timer().schedule(
                        new RequestTimer(message, _fileMgr, _out, message, _remotePeerId.get()),     
                        _peerMgr.getUnchokingInterval() * 2
                );
            }
        }
    }
}
