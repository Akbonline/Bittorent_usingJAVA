import java.io.IOException;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class Process implements Runnable, FileHandlerListener, PeerHandlerListener {
    private final int _peerId;
    private final int _port;
    private final boolean _hasFile;
    private final Configuration _conf;
    private final FileHandler _fileMgr;
    private final PeerHandler _peerMgr;
    private final LoggerMessages _eventLogger;
    private final AtomicBoolean _fileCompleted = new AtomicBoolean(false);
    private final AtomicBoolean _peersFileCompleted = new AtomicBoolean(false);
    private final AtomicBoolean _terminate = new AtomicBoolean(false);
    private final Collection<ThreadHandler> _connHandlers =
            Collections.newSetFromMap(new ConcurrentHashMap<ThreadHandler, Boolean>());

    public Process(int peerId, String address, int port, boolean hasFile, Collection<PeerInformation> peerInfo, Configuration conf) {
        _peerId = peerId;
        _port = port;
        _hasFile = hasFile;
        _conf = conf;    
        _fileMgr = new FileHandler(_peerId, _conf);
        ArrayList<PeerInformation> remotePeers = new ArrayList<>(peerInfo);
        for (PeerInformation ri : remotePeers) {
            if ((int)(ri.capsule.get(0)) == peerId) {   

                remotePeers.remove(ri);
                break;
            }
        }
        _peerMgr = new PeerHandler(_peerId, remotePeers, _fileMgr.getBitmapSize(), _conf);
        _eventLogger = new LoggerMessages(peerId);
        _fileCompleted.set(_hasFile);
    }

    void init() {
        _fileMgr.registerListener(this);
        _peerMgr.registerListener(this);

        if (_hasFile) {
            AssistLog.getLogger().debug("Spltting file");
            _fileMgr.splitFile();
            _fileMgr.setAllParts();
        }
        else {
            AssistLog.getLogger().debug("Peer does not have file");
        }

        // Start PeerMnager Thread
        Thread t = new Thread(_peerMgr);
        t.setName(_peerMgr.getClass().getName());
        t.start();
    }

    @Override
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(_port);
            while (!_terminate.get()) {
                try {
                    AssistLog.getLogger().debug(Thread.currentThread().getName() + ": Peer " + _peerId + " listening on port " + _port + ".");
                    addConnHandler(new ThreadHandler(_peerId, serverSocket.accept(), _fileMgr, _peerMgr));

                } catch (Exception e) {
                    AssistLog.getLogger().warning(e.toString());
                }
            }
        } catch (IOException ex) {
        	AssistLog.getLogger().warning(ex.toString());
        } finally {
        	AssistLog.getLogger().warning(Thread.currentThread().getName()
                    + " terminating, TCP connections will no longer be accepted.");
        }
    }

    void connectToPeers(Collection<PeerInformation> peersToConnectTo) {
        Iterator<PeerInformation> iter = peersToConnectTo.iterator();
        while (iter.hasNext()) {
            do {
                Socket socket = null;
                PeerInformation peer = iter.next();
                try {
                    AssistLog.getLogger().debug(" Connecting to peer: " + (String) peer.capsule.get(0)  
                            + " (" + peer.capsule.get(1) + ":" + peer.capsule.get(2) + ")");   
                    socket = new Socket(peer.capsule.get(1).toString(), (int) peer.capsule.get(2));    
                    if (addConnHandler(new ThreadHandler(_peerId, true, (int) peer.capsule.get(0),   
                            socket, _fileMgr, _peerMgr))) {
                        iter.remove();
                        AssistLog.getLogger().debug(" Connected to peer: " + peer.capsule.get(0)
                                + " (" + peer.capsule.get(1) + ":" + peer.capsule.get(2) + ")");

                    }
                }
                catch (ConnectException ex) {
                    AssistLog.getLogger().warning("could not connect to peer " + peer.capsule.get(0)  
                            + " at address " + peer.capsule.get(1) + ":" + peer.capsule.get(2));	
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException ex1)
                        {}
                    }
                }
                catch (IOException ex) {
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException ex1)
                        {}
                    }
                    AssistLog.getLogger().warning(ex.toString());
                }
            }
            while (iter.hasNext());

            // Keep trying until they all connect
            iter = peersToConnectTo.iterator();
            try {
                Thread.sleep(5);
            } catch (InterruptedException ex) {
            }
        }
    }

    @Override
    public void neighborsCompletedDownload() {
        AssistLog.getLogger().debug("all peers completed download");
        _peersFileCompleted.set(true);
        if (_fileCompleted.get() && _peersFileCompleted.get()) {
            // The process can quit
            _terminate.set(true);
            System.exit(0);
        }
    }

    @Override
    public synchronized void fileCompleted() {
        AssistLog.getLogger().debug("local peer completed download");
        _eventLogger.logComplete();
        _fileCompleted.set(true);
        if (_fileCompleted.get() && _peersFileCompleted.get()) {
            // The process can quit
            _terminate.set(true);
            System.exit(0);
        }
    }

    @Override
    public synchronized void pieceArrived(int partIdx) {
        for (ThreadHandler connHanlder : _connHandlers) {
            try {
				connHanlder.send(new Messages((byte) 4, partIdx));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            if (!_peerMgr.isInteresting(connHanlder.getRemotePeerId(), _fileMgr.getReceivedParts())) {
                try {
					connHanlder.send(new Messages((byte) 3));
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }
    }

    private synchronized boolean addConnHandler(ThreadHandler connHandler) {
        if (!_connHandlers.contains(connHandler)) {
            _connHandlers.add(connHandler);
            new Thread(connHandler).start();
            try {
                wait(10);
            } catch (InterruptedException e) {
                AssistLog.getLogger().warning(e.toString());
            }

        }
        else {
            AssistLog.getLogger().debug("Peer " + connHandler.getRemotePeerId() + " is trying to connect but a connection already exists");
        }
        return true;
    }

    @Override
    public synchronized void chockedPeers(Collection<Integer> chokedPeersIds) {
        for (ThreadHandler ch : _connHandlers) {
            if (chokedPeersIds.contains(ch.getRemotePeerId())) {
                AssistLog.getLogger().debug("Choking " + ch.getRemotePeerId());
                try {
					ch.send(new Messages((byte) 0));
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }
    }

    @Override
    public synchronized void unchockedPeers(Collection<Integer> unchokedPeersIds) {
        for (ThreadHandler ch : _connHandlers) {
            if (unchokedPeersIds.contains(ch.getRemotePeerId())) {
                AssistLog.getLogger().debug("Unchoking " + ch.getRemotePeerId());
                try {
					ch.send(new Messages((byte) 1));
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }
    }
}
