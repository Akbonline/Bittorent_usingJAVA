import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class Read extends DataInputStream{
	//Constructor
	public Read(InputStream in) {
		super(in);
		// TODO Auto-generated constructor stub
	}
	
	//when handshake is not received yet.    
	public HandshakeMessage readData() throws IOException{
		HandshakeMessage handshakeMessage = new HandshakeMessage();
		handshakeMessage.readHandshakeMessage(this);
		return handshakeMessage;
	}
	
	//TODO: Not sure if it's correct or not
	public Messages readMsgData() throws IOException, ClassNotFoundException{
		final int length = readInt();
        final int payloadLength = length - 1; // subtract 1 for the message type
        Messages message = new Messages(readByte(), new byte[payloadLength]);
        message.readMessage(this);
        return message;
	}
	

}
