public interface FileHandlerListener {

    public void fileCompleted();
    public void pieceArrived (int partIdx);
}
